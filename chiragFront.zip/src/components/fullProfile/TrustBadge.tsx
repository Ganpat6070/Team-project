import React from 'react'

const TrustBadge = () => {
  return (
    <div>
      
    </div>
  )
}

export default TrustBadge